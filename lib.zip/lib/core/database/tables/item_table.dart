import 'package:drift/drift.dart';

/// Таблица объектов коллекции.
class ItemTable extends Table {
  /// Идентификатор объекта.
  TextColumn get id => text()();

  /// Коллекция.
  TextColumn get collectionId => text()();

  /// Раздел.
  TextColumn get sectionId => text().nullable()();

  /// Порядок отображения.
  IntColumn get sortOrder => integer().withDefault(
        const Constant(0),
      )();

  /// Дата создания.
  DateTimeColumn get createdAt => dateTime()();

  /// Дата изменения.
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => {
        id,
      };
}