import 'package:drift/drift.dart';

/// Таблица значений полей объектов.
class ItemValueTable extends Table {
  /// Идентификатор значения.
  TextColumn get id => text()();

  /// Объект.
  TextColumn get itemId => text()();

  /// Поле.
  TextColumn get fieldId => text()();

  /// Значение.
  TextColumn get value => text()();

  @override
  Set<Column> get primaryKey => {
        id,
      };
}