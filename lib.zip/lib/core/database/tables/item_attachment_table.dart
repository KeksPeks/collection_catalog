import 'package:drift/drift.dart';

/// Таблица файлов объектов.
class ItemAttachmentTable extends Table {
  /// Идентификатор файла.
  TextColumn get id => text()();

  /// Объект.
  TextColumn get itemId => text()();

  /// Путь.
  TextColumn get path => text()();

  /// Тип файла.
  TextColumn get type => text()();

  @override
  Set<Column> get primaryKey => {
        id,
      };
}