import 'package:drift/drift.dart';

import 'tables/collection_table.dart';
import 'tables/field_table.dart';
import 'tables/collection_section_table.dart';

part 'app_database.g.dart';

@DriftDatabase(
  tables: [
    CollectionTable,
    FieldTable,
    CollectionSectionTable,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase(
    super.executor,
  );

  @override
  int get schemaVersion => 3;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createAll();
        },
        onUpgrade: (Migrator m, int from, int to) async {
          if (from < 2) {
            await m.createTable(
              collectionTable,
            );
          }

          if (from < 3) {
            await m.createTable(
              collectionSectionTable,
            );
          }
        },
      );
}