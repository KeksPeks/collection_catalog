import 'package:flutter/material.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';


import '../../../collections/domain/entities/collection.dart';

import '../providers/item_provider.dart';





class ItemEditorPage extends ConsumerStatefulWidget {


  final Collection collection;



  const ItemEditorPage({

    super.key,

    required this.collection,

  });





  @override
  ConsumerState<ItemEditorPage> createState() =>

      _ItemEditorPageState();


}






class _ItemEditorPageState

    extends ConsumerState<ItemEditorPage> {


  final Map<String,String> values = {};





  @override
  Widget build(BuildContext context) {


    return Scaffold(



      appBar:

          AppBar(

            title:

                const Text(

                  'Новый предмет',

                ),

          ),





      body:

          ListView(


            padding:

                const EdgeInsets.all(16),



            children:[



              if(widget.collection.fields.isEmpty)


                const Text(

                  'У коллекции нет полей',

                )



              else


                ...widget.collection.fields.map(

                  (field){


                    return Padding(

                      padding:

                          const EdgeInsets.only(

                            bottom:12,

                          ),



                      child:

                          TextField(


                            decoration:

                                InputDecoration(

                                  labelText:

                                      field.label,

                                  border:

                                      const OutlineInputBorder(),

                                ),



                            onChanged:(value){


                              values[field.id] = value;


                            },


                          ),


                    );


                  },


                ),




              const SizedBox(

                height:20,

              ),





              FilledButton(


                onPressed:(){


                  ref

                      .read(

                        itemsProvider

                            .notifier,

                      )

                      .createItem(

                        widget.collection.id,

                      );



                  Navigator.pop(context);


                },


                child:

                    const Text(

                      'Сохранить',

                    ),

              )



            ],


          ),


    );


  }


}