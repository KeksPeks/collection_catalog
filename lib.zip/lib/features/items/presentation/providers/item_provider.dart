import 'package:flutter_riverpod/flutter_riverpod.dart';


import '../../domain/entities/item.dart';

import '../../domain/services/item_service.dart';

import '../../data/repositories/memory_item_repository.dart';






final itemRepositoryProvider =

    Provider<MemoryItemRepository>(

  (ref) {


    return MemoryItemRepository();


  },

);







final itemServiceProvider =

    Provider<ItemService>(

  (ref) {


    final repository =

        ref.watch(

          itemRepositoryProvider,

        );



    return ItemService(

      repository,

    );


  },

);








final itemsProvider =

    StateNotifierProvider<

        ItemNotifier,

        List<Item>

    >(

  (ref) {


    final service =

        ref.watch(

          itemServiceProvider,

        );



    return ItemNotifier(

      service,

    );


  },

);









class ItemNotifier

    extends StateNotifier<List<Item>> {


  final ItemService service;



  ItemNotifier(

    this.service,

  ) : super([]);







  void createItem(

    String collectionId,

  ) {


    final item =

        service.create(

          collectionId:

              collectionId,

        );



    state = [

      ...state,

      item,

    ];


  }







  List<Item> getByCollection(

    String collectionId,

  ) {


    return service

        .getByCollection(

          collectionId,

        );


  }







  void deleteItem(

    String id,

  ) {


    service.delete(

      id,

    );



    state = [

      ...state.where(

        (item) =>

            item.id != id,

      ),

    ];


  }



}