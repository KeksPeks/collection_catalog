import '../../domain/entities/item.dart';

import '../../domain/repositories/item_repository.dart';



class MemoryItemRepository

    implements ItemRepository {


  final List<Item> _items = [];




  @override

  List<Item> getAll() {


    return List.unmodifiable(

      _items,

    );

  }





  @override

  List<Item> getByCollection(

    String collectionId,

  ) {


    return _items

        .where(

          (item) =>

              item.collectionId ==

              collectionId,

        )

        .toList();

  }





  @override

  Item? getById(

    String id,

  ) {


    try {


      return _items.firstWhere(

        (item) =>

            item.id == id,

      );


    } catch(_){


      return null;


    }


  }





  @override

  void add(

    Item item,

  ) {


    _items.add(item);


  }





  @override

  void update(

    Item item,

  ) {


    final index =

        _items.indexWhere(

          (old) =>

              old.id == item.id,

        );



    if(index != -1){


      _items[index] = item;


    }


  }





  @override

  void delete(

    String id,

  ) {


    _items.removeWhere(

      (item)=>

          item.id == id,

    );


  }


}