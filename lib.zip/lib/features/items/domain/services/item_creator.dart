import '../entities/item.dart';



class ItemCreator {



Item create({

 required String collectionId,

 String? storageNodeId,

})
  
  {


    final now = DateTime.now();



return Item(

 id:
    now.microsecondsSinceEpoch.toString(),


 collectionId:
    collectionId,


 storageNodeId:
    storageNodeId,


 values:
    const [],


 createdAt:
    now,


 updatedAt:
    now,

);


  }



}