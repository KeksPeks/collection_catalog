import '../entities/item.dart';
import '../entities/item_attachment.dart';
import '../entities/item_value.dart';

/// Репозиторий объектов коллекции.
abstract class ItemRepository {
  /// Получить все объекты коллекции.
  Future<List<Item>> getItems(
    String collectionId,
  );

  /// Получить объект.
  Future<Item?> getItem(
    String id,
  );

  /// Создать объект.
  Future<void> saveItem(
    Item item,
  );

  /// Обновить объект.
  Future<void> updateItem(
    Item item,
  );

  /// Удалить объект.
  Future<void> deleteItem(
    String id,
  );

  /// Получить значения полей объекта.
  Future<List<ItemValue>> getValues(
    String itemId,
  );

  /// Сохранить значение поля.
  Future<void> saveValue(
    ItemValue value,
  );

  /// Обновить значение поля.
  Future<void> updateValue(
    ItemValue value,
  );

  /// Удалить значение поля.
  Future<void> deleteValue(
    String id,
  );

  /// Получить файлы объекта.
  Future<List<ItemAttachment>> getAttachments(
    String itemId,
  );

  /// Добавить файл.
  Future<void> saveAttachment(
    ItemAttachment attachment,
  );

  /// Удалить файл.
  Future<void> deleteAttachment(
    String id,
  );
}