import '../../../../shared/domain/entities/auditable_entity.dart';

/// Экземпляр объекта коллекции.
///
/// Например:
/// - одна монета;
/// - одна банкнота;
/// - одна книга;
/// - одна карточка Pokémon.
///
/// Сам объект не хранит значения полей.
/// Все значения находятся в ItemValue.
class Item extends AuditableEntity {
  /// Идентификатор коллекции.
  final String collectionId;

  /// Идентификатор раздела.
  final String? sectionId;

  /// Порядок отображения внутри раздела.
  final int sortOrder;

  const Item({
    required super.id,
    required super.createdAt,
    required super.updatedAt,
    required this.collectionId,
    this.sectionId,
    this.sortOrder = 0,
  });

  Item copyWith({
    String? collectionId,
    String? sectionId,
    int? sortOrder,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return Item(
      id: id,
      collectionId: collectionId ?? this.collectionId,
      sectionId: sectionId ?? this.sectionId,
      sortOrder: sortOrder ?? this.sortOrder,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}