/// Значение поля конкретного объекта.
///
/// Один Item содержит множество ItemValue.
///
/// Пример:
///
/// fieldId = country
/// value = Germany
///
/// fieldId = year
/// value = 1905
///
/// fieldId = material
/// value = Silver
class ItemValue {
  /// Идентификатор значения.
  final String id;

  /// Идентификатор объекта.
  final String itemId;

  /// Идентификатор поля.
  final String fieldId;

  /// Значение.
  ///
  /// Пока хранится строкой.
  /// Позже будут использоваться конвертеры типов.
  final String value;

  const ItemValue({
    required this.id,
    required this.itemId,
    required this.fieldId,
    required this.value,
  });

  ItemValue copyWith({
    String? itemId,
    String? fieldId,
    String? value,
  }) {
    return ItemValue(
      id: id,
      itemId: itemId ?? this.itemId,
      fieldId: fieldId ?? this.fieldId,
      value: value ?? this.value,
    );
  }
}