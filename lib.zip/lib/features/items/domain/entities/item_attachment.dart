/// Файл, прикреплённый к объекту коллекции.
///
/// Это может быть:
/// - фотография;
/// - PDF;
/// - видео;
/// - архив;
/// - любой другой файл.
class ItemAttachment {
  /// Идентификатор файла.
  final String id;

  /// Идентификатор объекта.
  final String itemId;

  /// Путь к файлу.
  final String path;

  /// Тип файла.
  final String type;

  const ItemAttachment({
    required this.id,
    required this.itemId,
    required this.path,
    required this.type,
  });

  ItemAttachment copyWith({
    String? itemId,
    String? path,
    String? type,
  }) {
    return ItemAttachment(
      id: id,
      itemId: itemId ?? this.itemId,
      path: path ?? this.path,
      type: type ?? this.type,
    );
  }
}